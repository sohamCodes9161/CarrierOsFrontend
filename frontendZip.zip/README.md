# CareerOS Frontend

React 18 + React Router 6 + Tailwind CSS 3 + DaisyUI 4, built on Vite. It talks to the existing CareerOS
Express backend (`/api/v1`) with no mock data and no changes to the backend.

## Run it

```bash
npm install
cp .env.example .env      # adjust VITE_API_BASE_URL if your backend isn't on localhost:5000
npm run dev               # http://localhost:5173
```

The dev server is pinned to port **5173** because the backend's CORS origin defaults to
`CLIENT_URL=http://localhost:5173` and the refresh-token cookie needs credentialed requests.
If you change the port, set `CLIENT_URL` in the backend's `.env` to match.

`npm run build` produces a static bundle in `dist/`. Serve it with SPA fallback (all paths -> `index.html`),
since routes such as `/p/:slug` are client-side.

## Environment

| Variable | Default | Purpose |
| --- | --- | --- |
| `VITE_API_BASE_URL` | `http://localhost:5000/api/v1` | Backend base URL including `/api/v1` |
| `VITE_ENABLE_REORDER` | `false` | Shows up/down reorder buttons in the portfolio editor (see below) |

## Structure

```
src/
  services/api/   fetch client (token handling, refresh-and-retry, timeouts, error mapping) + one module per backend area
  context/        AuthContext (session restore via refresh cookie), ToastContext
  hooks/          useApi, useAction, useAudioPolling, useSlugAvailability, useDocumentTitle
  components/     ui/ (buttons, cards, modal, score ring...), forms/, layout/, common/
  layouts/        AppLayout (drawer shell), AuthLayout, PublicLayout
  routes/         route table (lazy-loaded pages), ProtectedRoute, PublicOnlyRoute
  pages/          Landing, Login, Register, Dashboard, resume/, github/, interview/, career profile,
                  roadmap/, portfolio/ (editor + public page), Account, NotFound
  utils/          formatting, validation (mirrors backend zod rules), constants, portfolio helpers
```

## How it handles the backend

- **Auth**: the access token lives in memory only. The refresh token is the backend's httpOnly cookie.
  On load the app calls `/auth/refresh` then `/auth/me`. A 401 triggers one shared refresh and a retry, so
  concurrent requests never race the rotating refresh token.
- **Long AI calls** (resume, GitHub, interview, roadmap, career profile) use a 3 minute timeout and show a
  progress notice instead of a bare spinner.
- **Voice interviews**: the backend returns audio URLs as `null` and fills them in afterwards, so the session
  page polls `GET /interviews/:id` (about every 2.5 s, up to ~60 s) until audio appears. Answers can be typed or
  recorded. Where the browser supports live speech recognition (Chromium), the transcript streams into the
  answer box for review; otherwise the recording is uploaded and transcribed by the server.
- **Roadmap progress** updates optimistically and rolls back if the request fails.
- **Public portfolio** (`/p/:slug`) only renders `http(s)` links and validated colors, because that content is
  user-supplied and shown to anyone.
- **Errors**: the backend's own message is shown for 400/401/403/404/409/429; 5xx and network failures show a
  generic message so internals never leak.

## Known backend issue: portfolio reordering

`PATCH /portfolio/{section}/reorder` is registered after `PATCH /portfolio/{section}/:itemId`, so Express
matches `reorder` as an item id and the reorder endpoints fail. The reorder UI is therefore hidden by default.
Move the `/reorder` routes above the `/:itemId` routes in the backend's portfolio router, then set
`VITE_ENABLE_REORDER=true`.

## Notes

- In development React StrictMode runs effects twice, so opening a public portfolio locally may count two views.
- Live speech recognition in Chrome sends audio to Google's speech service; the answer box says so.
